
<?php
//menu 1 fallback menu register (1st simple menu then fallback code)

register_nav_menu( 'main_menu', __( 'Main Menu', 'arnab' ) );

//fallback code
/* menu fallback code */
	function bwqs_quickstart_default_menu() {
		echo '<ul class="nav navbar-nav">';   /* ul id r bodole div/class id hote pare html jamon thakbe */
		if ('page' != get_option('show_on_front')) {
		echo '<li><a href="'. home_url() . '/">Home</a></li>';
		}
		wp_list_pages('title_li=');
		echo '</ul>';
		
	}
	
	
	
//menu 2 simple menu

register_nav_menu( 'main_menu_right', __( 'Main Menu Right', 'arnab' ) );
//fallback code
/* menu fallback code */
	function bwqs_main_top_right__menu() {
		echo '<ul class="nav navbar-nav navbar-right">';   /* ul id r bodole div/class id hote pare html jamon thakbe */
		if ('page' != get_option('show_on_front')) {
		echo '<li class="dropdown"><a href="'. home_url() . '/">Home</a></li>';
		}
		wp_list_pages('title_li=');
		echo '</ul>';
	
	


	}

/* for log in log out menu https://wordpress.org/support/topic/send-users-to-woocommerce-my-account-page-instead-of-default-wp-loginlogout-pa */

/*Add LoginOut in Top Menu */
	
add_filter( 'wp_nav_menu_items', 'add_loginout_link', 10, 2 );
function add_loginout_link( $items, $args ) {
    
      
	
	  if (is_user_logged_in() && $args->theme_location == 'main_menu_right') {
	      
	        if (class_exists('Woocommerce')) {
	    global $woocommerce;
		$cart_contents_count = $woocommerce->cart->cart_contents_count;
		$cart_contents = sprintf(_n('%d item', '%d items', $cart_contents_count, 'your-theme-slug'), $cart_contents_count);
		$cart_total = $woocommerce->cart->get_cart_total();
		
			$items .= '
<li class="dropdown"><a href="" data-toggle="dropdown"><i class="glyphicon glyphicon-user"></i>
					<span class="caret"></span></a>
	<ul class="dropdown-menu">
	    <li><a href="' . get_permalink( wc_get_page_id( 'myaccount' ) ) . '">My Account</a></li>
	    <li><a href="">Wishlist</a></li>
	   </ul>				
</li>
<li class="dropdown"><a href="#" data-toggle="dropdown">  <i class="glyphicon glyphicon-shopping-cart"></i> 
					<span class="sr-only">Shopping Cart: </span>
					<span class="cart-contents">'.$cart_contents.'<span class="amount">'.$cart_total.'</span></span>
		     		<span class="caret"></span></a>
				<ul class="dropdown-menu">
	      <li><a href="' . get_permalink( wc_get_page_id( 'cart' ) ) . '">View Cart</a></li>
	  </ul>
</li>

}
';}
	}
	
               
	
	 
	  
	
	
	
	
	elseif (!is_user_logged_in() && $args->theme_location == 'main_menu_right') {
	    
			$items .= '
<li><a href="'.$woocommerce->cart->get_cart_url.'">Login</a></li>
<li><a href="'.$woocommerce->cart->get_cart_url.'">Register</a></li>'; } return $items; }  






?>